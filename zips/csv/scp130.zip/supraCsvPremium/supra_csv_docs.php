<?php
echo file_get_contents("http://supraliminalsolutions.com/supra-csv/supra_csv_docs.php");
