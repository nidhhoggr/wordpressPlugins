<?php
require_once("Debug.php");
require_once('CsvLib.php');
require_once('RemotePost.php');

class IngestCsv {

    public function ParseAndMap($filename) {
        $this->cp = new SupraCsvParser($filename);
        $mf = new SupraCsvMapperForm($this->cp);
        return $mf->getForm();
    }

    public function ingest($params) {
        $this->cp = new SupraCsvParser($params['filename']);
        $this->cp->ingestContent($params['mapping']);
    }

    public function getSupraCsvParser()
    {
        return $this->cp;
    }
}
