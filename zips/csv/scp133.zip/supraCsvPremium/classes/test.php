<?php

$sentence = "This , is , a , test";

var_dump(strstr($sentence,',', FALSE));
