<?php

require_once(dirname(__FILE__) . '/../../../wp-config.php');
require_once(dirname(__FILE__) . '/SupraCsvParser_Plugin.php');


$scpp = new SupraCsvParser_Plugin();
$scpp->createFileSystem(); 
