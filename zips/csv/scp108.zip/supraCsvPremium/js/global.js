$ = jQuery.noConflict();

var preset_id, filename_key, preset_name, preset_type;

