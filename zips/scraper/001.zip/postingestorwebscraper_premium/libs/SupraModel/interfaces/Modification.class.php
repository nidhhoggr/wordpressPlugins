<?php
interface Modification {

    public function save();
    public function delete();
}
