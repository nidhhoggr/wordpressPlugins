=== Supra Scraper Pro ===

Contributors: zmijevik
Author URI: http://www.supraliminalsolutions.com/blog/listings/supra-scraper/
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=CLC8GNV7TRGDU
Tags: scraper,webscraper,web parser,parser,web spider,spider,bot
Requires at least: 3.2.1
Tested up to: 3.5.1
Stable tag: 0.0.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

The purpose of this plugin is to scrape a list of links from a csv file or a textbox. The plugin also provides the ability to scrape page meta data into wordpress post meta. In addition to providing psotmeta the plugin also allows the user to customize the title and excerpt of a post by prepending or appending any additional information on a per-ingestion basis. Premium Users can take advantage of scraping pages into custom post types. In addition to all of these features, premium users also have the ability to randomize the scraping process in an attempt to bypass bot detectors.

== Description ==

The purpose of this plugin is to scrape a list of links from a csv file or a textbox. The plugin also provides the ability to scrape page meta data into wordpress post meta. In addition to providing psotmeta the plugin also allows the user to customize the title and excerpt of a post by prepending or appending any additional information on a per-ingestion basis. Premium Users can take advantage of scraping pages into custom post types. In addition to all of these features, premium users also have the ability to randomize the scraping process in an attempt to bypass bot detectors. 

== Installation ==


== Frequently Asked Questions ==


== Screenshots ==


== Changelog ==

= 0.1 =
- Hello World
