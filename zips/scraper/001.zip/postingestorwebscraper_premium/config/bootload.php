<?php

require_once(dirname(__FILE__) . '/../libs/HTML-DOM-Parser/simple_html_dom.php');
require_once(dirname(__FILE__) . '/../libs/SupraModel/SupraModel.class.php');

$dbuser = $wpdb->dbuser;
$dbpassword  = $wpdb->dbpassword;
$dbname = $wpdb->dbname;
$dbhost = $wpdb->dbhost;
$driver = 'mysql';

$wp_conn_args = compact('dbuser','dbname','dbpassword','dbhost','driver');

  public function configure() {

    $this->setTable("wp_posts");
    $this->setTableIdentifier("ID");
  }
}

class LinksErroredModel extends SupraModel {

    public function configure() {
        //$this->setTable("error");
    }
}

$WordpressModel = new WordpressModel($wp_conn_args); 

$LinksErroredModel = new LinksErroredModel($wp_conn_args); 
